This is a short web-project to set up a mobile website for the ACCB
(Aargauischer Computer Club Brugg).
It uses jQuery Mobile.

